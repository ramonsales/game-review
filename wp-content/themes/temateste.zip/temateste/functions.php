<?php
    // Habilitar imagem de destaque
    add_theme_support( 'post-thumbnails' );

    // Registrar menu de navegação
    register_nav_menus( array(
        'menu' => 'Menu principal',
    ) );

    // Bruxaria da classe do link
    add_filter( 'nav_menu_link_attributes', function($atts) {
        $atts['class'] = "nav-link";
        return $atts;
    }, 100, 1 );

    wp_enqueue_style( 'style', get_stylesheet_uri() );