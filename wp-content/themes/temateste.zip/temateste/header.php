<!DOCTYPE html>
<html>
<head>
    <title>Tema Teste</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
</head>
<body>
<header class="my-4">
    <div class="container">
        <div class="row">
            <header>
                <h1 class="text-center"><a class="titulo_noticias" href="<?php echo home_url(); ?>">Notícias</a></h1>
                <?php
                    if(is_user_logged_in()) {
                        $user = wp_get_current_user();
                        echo "<p> Olá, " . $user->user_firstname . "! </p>";
                    } else {
                        echo "Faça login <a href='" . home_url('/wp-login.php') . "'>aqui</a>.";
                    }
                    $args = array('menu' => 'menu', 'menu_class' => 'navbar-nav mr-auto', 'container_class' => 'navbar navbar-expand-lg navbar-light bg-light',
                        'container' => 'nav', 'link_class' => 'testando123');
                    wp_nav_menu($args);
                ?>
            </header>
        </div>
    </div>
</header>
