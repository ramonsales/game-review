<?php get_header(); ?>
    <main>
        <div class="container">
            <div class="row">
                <?php
                    if ( have_posts() ) : ?>
                        <?php while ( have_posts() ) : the_post(); ?>

                            <div class="col-md-3 mb-3">
                                <div class="card">
                                <img src="http://via.placeholder.com/250" alt="image da notícia" class="card-img-left">
                                <div class="card-body">
                                        <h5 class="card-title"><?php the_title(); ?></h5>
                                        <p class="card-text"><?php the_content(); ?></p>
                                        <a href="<?php the_permalink(); ?>" class="card-link">Leia mais</a>
                                    </div>
                                </div>
                            </div>
                            
                            <?php endwhile; else: ?>
                            <p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
                    <?php endif; ?>
            </div>
        </div>
    </main>
<?php get_footer(); ?>
